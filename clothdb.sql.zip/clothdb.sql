-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2022 at 08:20 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clothdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `size` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `amount` int(11) NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cloth`
--

CREATE TABLE `cloth` (
  `c_id` int(11) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `size` varchar(10) NOT NULL,
  `pic` varchar(250) NOT NULL,
  `price` double NOT NULL,
  `ct_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cloth`
--

INSERT INTO `cloth` (`c_id`, `c_name`, `color`, `gender`, `size`, `pic`, `price`, `ct_id`, `stock`) VALUES
(12, 'Two Tone High Low He', 'Black/White', 'F', 'M', 'c1.jpg', 390, 1, 91),
(13, 'Star Tassel Chain Br', 'Silver', 'F', 'F', 'j1.JPG', 890, 2, 90),
(14, 'Striped Shirt', 'Grey', 'U', 'M', 'c7.JPG', 10000, 1, 41),
(15, 'Letter Front Ankle B', 'Khaki', 'M', 'F', 'sh1.JPG', 7000, 3, 87);

-- --------------------------------------------------------

--
-- Table structure for table `cloth_type`
--

CREATE TABLE `cloth_type` (
  `ct_id` int(11) NOT NULL,
  `ct_desc` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cloth_type`
--

INSERT INTO `cloth_type` (`ct_id`, `ct_desc`) VALUES
(1, 'clothing'),
(2, 'jewery'),
(3, 'shoes');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `no` int(11) NOT NULL,
  `o_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `c_name` varchar(50) NOT NULL,
  `date_order` date NOT NULL,
  `price` double NOT NULL,
  `amount` int(11) NOT NULL,
  `total` double NOT NULL,
  `card_number` varchar(20) NOT NULL,
  `order_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`no`, `o_id`, `c_id`, `username`, `c_name`, `date_order`, `price`, `amount`, `total`, `card_number`, `order_status`) VALUES
(6, 1, 15, 'testuser1', 'Letter Front Ankle B', '0000-00-00', 7000, 5, 35000, '123456789', 'processing'),
(7, 1, 14, 'testuser1', 'Striped Shirt', '0000-00-00', 10000, 5, 50000, '123456789', 'processing'),
(8, 2, 12, 'user1', 'Two Tone High Low He', '0000-00-00', 390, 7, 2730, 'efgdfgdfgdfgdfg', 'placed'),
(9, 2, 13, 'user1', 'Star Tassel Chain Br', '0000-00-00', 890, 7, 6230, 'efgdfgdfgdfgdfg', 'placed'),
(10, 3, 14, 'user1', 'Striped Shirt', '0000-00-00', 10000, 1, 10000, 'asdfsdfsdfsdfsdf', 'placed'),
(11, 4, 13, 'user1', 'Star Tassel Chain Br', '0000-00-00', 890, 1, 890, 'sdfdsfsdfefsdf', 'placed'),
(12, 4, 15, 'user1', 'Letter Front Ankle B', '0000-00-00', 7000, 1, 7000, 'sdfdsfsdfefsdf', 'placed'),
(13, 5, 12, 'testuser1', 'Two Tone High Low He', '0000-00-00', 390, 1, 390, 'fghfghfghfgh', 'processing'),
(14, 5, 15, 'testuser1', 'Letter Front Ankle B', '0000-00-00', 7000, 1, 7000, 'fghfghfghfgh', 'processing'),
(17, 6, 15, 'testuser1', 'Letter Front Ankle B', '0000-00-00', 7000, 4, 28000, 'sd', 'placed'),
(18, 7, 14, 'user1', 'Striped Shirt', '0000-00-00', 10000, 3, 30000, 'dfsd', 'placed');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `password`, `name`, `email`, `status`) VALUES
(1, 'testuser1', '123456789', 'Test User1', 'testuser1@mail.comm', 'Customer'),
(3, 'admin', '1234', 'admin', 'admin@admin.com', 'Admin'),
(4, 'user1', '1234', 'user1 eiei', 'user1@mail.com', 'Customer');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `cloth`
--
ALTER TABLE `cloth`
  ADD PRIMARY KEY (`c_id`),
  ADD KEY `ct_id` (`ct_id`);

--
-- Indexes for table `cloth_type`
--
ALTER TABLE `cloth_type`
  ADD PRIMARY KEY (`ct_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`no`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `cloth`
--
ALTER TABLE `cloth`
  MODIFY `c_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cloth_type`
--
ALTER TABLE `cloth_type`
  MODIFY `ct_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `cloth` (`c_id`) ON UPDATE CASCADE;

--
-- Constraints for table `cloth`
--
ALTER TABLE `cloth`
  ADD CONSTRAINT `cloth_ibfk_1` FOREIGN KEY (`ct_id`) REFERENCES `cloth_type` (`ct_id`) ON UPDATE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`c_id`) REFERENCES `cloth` (`c_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
